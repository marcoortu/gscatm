library(testthat)
library(gscatm)

test_check("gscatm")
