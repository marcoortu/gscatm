# tests/testthat/test-fit_gsca_topic_model.R

test_that("fit_gsca_topic_model works correctly", {
  library(gscatm)
  library(Matrix)
  library(quanteda)

  # Prepare sample data
  docs <- c("This is a sample document.",
            "This document is another example.",
            "Topic modeling is fun.",
            "We are integrating GSCA with topic modeling.")

  dfm <- dfm(tokens(docs))
  dtm <- as(dfm, "dgCMatrix")
  covariates <- data.frame(length = rowSums(dtm))

  # Create path matrix
  P <- ncol(covariates)
  K <- 2
  path_matrix <- matrix(0, P + K, P + K)
  path_matrix[1:P, (P+1):(P+K)] <- 1  # Paths from covariates to topics

  # Fit the model
  model <- fit_gsca_topic_model(dtm, covariates, K = K,
                                path_matrix = path_matrix,
                                max_iter = 10)

  # Basic model checks
  expect_s3_class(model, "gsca_topic_model")

  # Check dimensions of topic model components
  expect_equal(dim(model$phi), c(K, ncol(dtm)))
  expect_equal(dim(model$theta), c(nrow(dtm), K))

  # Check dimensions of GSCA components
  expect_equal(dim(model$gamma), c(nrow(dtm), P + K))
  expect_equal(dim(model$path_matrix), c(P + K, P + K))
  expect_equal(dim(model$weight_matrix), c(P + K, ncol(dtm)))

  # Check probability constraints
  expect_true(all(abs(rowSums(model$phi) - 1) < 1e-6))
  expect_true(all(abs(rowSums(model$theta) - 1) < 1e-6))

  # Check structural validity
  expect_true(all(model$gamma[, 1:P] - scale(as.matrix(covariates)) < 1e-6))
  expect_true(all(model$path_matrix[1:P, 1:P] == 0))  # No paths between covariates
})

test_that("fit_gsca_topic_model converges correctly", {
  library(gscatm)
  library(Matrix)
  library(quanteda)

  # Prepare sample data
  docs <- c("This is a sample document.",
            "This document is another example.",
            "Topic modeling is fun.",
            "We are integrating GSCA with topic modeling.")

  dfm <- dfm(tokens(docs))
  dtm <- as(dfm, "dgCMatrix")
  covariates <- data.frame(length = rowSums(dtm))

  # Parameters
  P <- ncol(covariates)
  K <- 2

  # Create path matrix
  path_matrix <- matrix(0, P + K, P + K)
  path_matrix[1:P, (P+1):(P+K)] <- 1

  # Test convergence
  model <- fit_gsca_topic_model(dtm, covariates, K = K,
                                path_matrix = path_matrix,
                                max_iter = 10)

  # Check model components
  expect_s3_class(model, "gsca_topic_model")
  expect_equal(dim(model$phi), c(K, ncol(dtm)))
  expect_equal(dim(model$theta), c(nrow(dtm), K))
  expect_equal(dim(model$gamma), c(nrow(dtm), P + K))

  # Check probability constraints
  expect_true(all(abs(rowSums(model$phi) - 1) < 1e-6))
  expect_true(all(abs(rowSums(model$theta) - 1) < 1e-6))

  # Check structural constraints
  expect_true(all(model$path_matrix[1:P, 1:P] == 0))
  expect_true(all(model$path_matrix[(P+1):(P+K), 1:P] == 0))

  # Test max_iter boundary
  model_quick <- fit_gsca_topic_model(dtm, covariates, K = K,
                                      path_matrix = path_matrix,
                                      max_iter = 1)
  expect_s3_class(model_quick, "gsca_topic_model")
})

test_that("fit_gsca_topic_model handles invalid inputs", {
  library(gscatm)
  library(Matrix)
  library(quanteda)

  # Prepare sample data
  docs <- c("This is a sample document.",
            "This document is another example.")

  dfm <- dfm(tokens(docs))
  dtm <- as(dfm, "dgCMatrix")
  covariates <- data.frame(length = rowSums(dtm))

  # Test invalid K
  expect_error(fit_gsca_topic_model(dtm, covariates, K = 0))

  # Test invalid path matrix
  P <- ncol(covariates)
  K <- 2
  bad_path_matrix <- matrix(0, P, P)  # Wrong dimensions
  expect_error(fit_gsca_topic_model(dtm, covariates, K = K,
                                    path_matrix = bad_path_matrix))

})

test_that("fit_gsca_topic_model handles handles zero-inflated topic distribution", {
  library(gscatm)
  library(Matrix)
  library(quanteda)

  # Prepare sample data
  docs <- c("This is a sample document.",
            "This document is another example.",
            "Topic modeling is fun.",
            "We are integrating GSCA with topic modeling.")

  dfm <- dfm(tokens(docs))
  dtm <- as(dfm, "dgCMatrix")
  covariates <- data.frame(length = rowSums(dtm))

  # Parameters
  P <- ncol(covariates)
  K <- 2

  # Create path matrix
  path_matrix <- matrix(0, P + K, P + K)
  path_matrix[1:P, (P+1):(P+K)] <- 1

  # Test convergence
  model <- fit_gsca_topic_model(dtm, covariates, K = K,
                                path_matrix = path_matrix,
                                model = "zero-inflated",
                                max_iter = 10)
  # Check model components
  expect_s3_class(model, "gsca_topic_model")
  expect_equal(dim(model$phi), c(K, ncol(dtm)))
  expect_equal(dim(model$theta), c(nrow(dtm), K))
  expect_equal(dim(model$gamma), c(nrow(dtm), P + K))

})

test_that("fit_gsca_topic_model handles handles dirichlet topic distribution", {
  library(gscatm)
  library(Matrix)
  library(quanteda)

  # Prepare sample data
  docs <- c("This is a sample document.",
            "This document is another example.",
            "Topic modeling is fun.",
            "We are integrating GSCA with topic modeling.")

  dfm <- dfm(tokens(docs))
  dtm <- as(dfm, "dgCMatrix")
  covariates <- data.frame(length = rowSums(dtm))

  # Parameters
  P <- ncol(covariates)
  K <- 2

  # Create path matrix
  path_matrix <- matrix(0, P + K, P + K)
  path_matrix[1:P, (P+1):(P+K)] <- 1

  # Test convergence
  model <- fit_gsca_topic_model(dtm, covariates, K = K,
                                path_matrix = path_matrix,
                                model = "dirichlet",
                                max_iter = 10)
  # Check model components
  expect_s3_class(model, "gsca_topic_model")
  expect_equal(dim(model$phi), c(K, ncol(dtm)))
  expect_equal(dim(model$theta), c(nrow(dtm), K))
  expect_equal(dim(model$gamma), c(nrow(dtm), P + K))
})

test_that("fit_gsca_topic_model handles wrong topic model specificaiton", {
  library(gscatm)
  library(Matrix)
  library(quanteda)

  # Prepare sample data
  docs <- c("This is a sample document.",
            "This document is another example.",
            "Topic modeling is fun.",
            "We are integrating GSCA with topic modeling.")

  dfm <- dfm(tokens(docs))
  dtm <- as(dfm, "dgCMatrix")
  covariates <- data.frame(length = rowSums(dtm))

  # Parameters
  P <- ncol(covariates)
  K <- 2

  # Create path matrix
  path_matrix <- matrix(0, P + K, P + K)
  path_matrix[1:P, (P+1):(P+K)] <- 1

  # Test convergence
  expect_error(fit_gsca_topic_model(dtm, covariates, K = K,
                                path_matrix = path_matrix,
                                model = "none",
                                max_iter = 10))
})
