# GSCA Topic Model

The `fit_gsca_topic_model` function implements a **Generalized Structured Component Analysis (GSCA) Topic Model**. It combines **topic modeling** and **structural equation modeling (SEM)** to study relationships between document covariates (e.g., metadata) and topic proportions extracted from a document-term matrix (DTM). Here's a detailed breakdown:

### Input Parameters:
1. **`dtm` (Document-Term Matrix)**: A sparse matrix representing document-term frequencies.
2. **`covariates`**: A matrix or dataframe of covariates (metadata) associated with the documents.
3. **`K` (Number of Topics)**: Specifies the number of topics to extract.
4. **`model`**: Type of topic distribution, such as:
   - `"logistic-normal"`: Logistic normal priors for topic proportions.
   - `"dirichlet"`: Dirichlet priors.
   - `"zero-inflated"`: Allows for zero-inflated topic distributions.
5. **`path_matrix`**: Specifies structural paths for SEM; defaults to paths from all covariates to all topics.
6. **`weight_matrix`**: Initial weights for GSCA; if `NULL`, initialized randomly.
7. **`max_iter`**: Maximum iterations for the Expectation-Maximization (EM) algorithm.
8. **`tol`**: Convergence tolerance.
9. **`alpha`**: Smoothing parameter for the topic-word distributions.
10. **`reference_topic`**: Topic to use as the reference category for covariate effect estimation.

---

### Key Components of the Function:
#### Initialization:
- **`phi`**: Topic-word distributions initialized randomly and normalized.
- **`gamma`**: Component scores initialized for both covariates and topics.
- **`theta`**: Document-topic proportions initialized via `gamma`.

#### **Expectation-Maximization (EM) Algorithm**:
1. **E-Step**:
   - Updates **`theta`** (document-topic proportions) based on current `gamma`.
   - Computes posterior probabilities of topics given the DTM and topic distributions.

2. **M-Step**:
   - Updates **`phi`** (topic-word distributions) by weighted counts of words under posterior probabilities.
   - Updates **`gamma`** via regression using the GSCA structural model:
     - Path coefficients (`path_matrix`) are updated using Ridge regression.
     - Covariate effects on topics are estimated iteratively.

#### **Perplexity Calculation**:
- Perplexity is used to monitor the model's fit. Lower perplexity indicates better model performance.

#### **Convergence Checks**:
- Stops iterating if parameter updates (`phi`, `theta`, `gamma`) stabilize (change below `tol`) or if perplexity becomes stable over a window of iterations.

---

### Covariate Effects Estimation:
1. The **`reference_topic`** is used for calculating log-ratios of other topics' proportions relative to the reference.
2. Fits **weighted logistic regression** for each log-ratio using covariates as predictors.
3. Outputs coefficients, odds ratios, and confidence intervals for covariate effects on topic proportions.

---

### Output:
Returns a list containing:
1. **`phi`**: Final topic-word distributions.
2. **`theta`**: Final document-topic proportions.
3. **`gamma`**: Final component scores.
4. **`path_matrix`**: Final structural path coefficients.
5. **`weight_matrix`**: Final weights for GSCA.
6. **`effects`**: Data frame of covariate effects on topics.
7. **`fit`**: Model fit statistics (AIC, BIC, McFadden’s R², etc.).
8. **`convergence`**: Diagnostics including iteration count, final deltas, and perplexity history.

---

### Example Use:
1. **Data Preparation**:
   - The document-term matrix (`dtm`) represents term frequencies in documents.
   - `covariates` contain metadata for the documents (e.g., author, date, etc.).

2. **Model Fitting**:
   - Fit the GSCA topic model with the desired number of topics and reference topic.
   - Analyze covariate effects on topic proportions.

---

### Applications:
1. **Exploring Relationships**:
   - Links between document metadata (e.g., author demographics) and topic distributions.
2. **Topic Interpretation**:
   - Identify dominant topics in documents and how metadata affects their prominence.
3. **Complex Dependencies**:
   - Incorporates structural relationships beyond standard topic modeling (e.g., LDA).

## Example Usage

```r
library(gscatm)

# Generate sample data
set.seed(42)
sample_data <- generate_sample_data(
  n_docs = 10,
  n_terms = 50,
  n_topics = 3,
  n_covariates = 3
)

# Fit the model
model <- fit_gsca_topic_model(
  dtm = sample_data$dtm,
  covariates = sample_data$covariates,
  K = 3,
  model = "logistic-normal"
)

# Examine topic-word distributions
top_terms <- apply(model$phi, 1, function(x) {
  names(sort(x, decreasing = TRUE))[1:10]
})
print("Top terms per topic:")
print(top_terms)

# Compare estimated vs true topic proportions
plot(sample_data$true_theta[,1], model$theta[,1],
     xlab = "True proportions", ylab = "Estimated proportions",
     main = "Topic 1 Proportions")
```
