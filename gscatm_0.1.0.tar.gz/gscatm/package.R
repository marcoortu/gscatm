#' @importFrom stats logLik cov2cor toeplitz terms update
#' @importFrom utils head tail
#' @importFrom Matrix Matrix
#' @keywords internal
"_PACKAGE"
